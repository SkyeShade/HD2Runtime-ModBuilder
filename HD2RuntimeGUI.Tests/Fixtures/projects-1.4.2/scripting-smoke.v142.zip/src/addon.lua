local hd2=require('mods/skyeshade/hd2runtime')

local generated={}
local function add(build)
    local ok,operation=pcall(build)
    if ok then generated[#generated+1]=operation
    else print('[ModBuilder] operation skipped: '..tostring(operation)) end
end
add(function() return hd2.ensure({
    patch={
        id='output-41a463f1b616d145e6c6e898',
        target=hd2.weapon('AR-23 Liberator'):ammunition(),
        allow_shared=true,
        field=hd2.fields.ammunition.projectile,
        expect=hd2.weapon('AR-23 Liberator'):ammunition():projectile(),
        value=hd2.attack_output('output/v1/projectile/eat-700-expendable-napalm'),
    }
}) end)
add(function() return hd2.ensure({
    patch={
        id='entity-20ac5e742cf0bf56905ab300',
        target=hd2.backpack('SH-20 Ballistic Shield Backpack'):damage_zone('zone_0'),
        allow_unverified_effect=true,
        field=hd2.fields.zone.armor,
        expect=4,
        value=6,
    }
}) end)
add(function() return hd2.ensure({
    patch={
        id='entity-5427da7a2bb0874032a83ac4',
        target=hd2.pod_rack('Resupply pod'):slot(1),
        allow_shared=true,
        field=hd2.fields.payload.entity,
        expect=hd2.pickup('pickup/v1/supply-box/d0e8fed8c01ceb1f'),
        value=hd2.pickup('pickup/v1/grenade-box/5ad3b36a5d3adbb7'),
    }
}) end)

-- Custom Lua: src/addon.lua (hand-written; ModBuilder copies it unchanged)
local function addon(...)
-- Custom HD2Runtime Lua for this mod. ModBuilder's generated modifications are registered before this runs.
-- `hd2` is already required; the event API reference and snippets are in ModBuilder's Custom Lua page.
local mod = hd2.mod()
hd2.events.on('player_died', function(event)
    if event.local_player and event.position and event.cause.source ~= 'mod' then
        hd2.explosions.spawn('Hellbomb', {position = event.position})
    end
end)

-- edited outside ModBuilder
hd2.events.on('player_damage_dealt', function(event)
    -- event.player, event.local_player, event.damage, event.total, event.sources, event.unattributed
    for _, source in ipairs(event.sources) do
        -- source.type, source.name, source.damage
    end
end)

hd2.diagnostics.hd2.status.apply(event.entity, 'fire', {buildup = 100})
end
addon()
return generated
