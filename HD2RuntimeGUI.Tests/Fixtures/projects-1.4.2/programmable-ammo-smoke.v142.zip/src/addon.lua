local hd2=require('mods/skyeshade/hd2runtime')

local operations={}
local function add(build)
    local ok,operation=pcall(build)
    if ok then operations[#operations+1]=operation
    else print('[ModBuilder] operation skipped: '..tostring(operation)) end
end
add(function() return hd2.ensure({
    transaction={
        id='support-a7f97f57e1fd0aeb842ccb57',
        target=hd2.support_weapon('MG-206 Heavy Machine Gun'),
        allow_unverified_effect=true,
        allow_unverified_reference=true,
        changes={
            {field=hd2.fields.function_ammo.projectile,expect='none',value=hd2.attack_output('output/v1/projectile/gl-52-de-escalator')},
            {field=hd2.fields.weapon_function.left,expect='none',value='programmable_ammo'},
        },
    }
}) end)
return operations
