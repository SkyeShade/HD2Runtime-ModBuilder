local hd2=require('mods/skyeshade/hd2runtime')

local operations={}
local function add(build)
    local ok,operation=pcall(build)
    if ok then operations[#operations+1]=operation
    else print('[ModBuilder] operation skipped: '..tostring(operation)) end
end
add(function() return hd2.ensure({
    patch={
        id='output-94b1cad417a3c468a38d0995',
        target=hd2.support_weapon('EAT-17 Expendable Anti-Tank'):attack('primary'),
        allow_unverified_effect=true,
        field=hd2.fields.attack.projectile,
        expect=hd2.support_weapon('EAT-17 Expendable Anti-Tank'):attack('primary'):projectile(),
        value=hd2.attack_output('output/v1/projectile/eat-411-leveller'),
    }
}) end)
add(function() return hd2.ensure({
    patch={
        id='output-6e0ff7cf6a332ec583f5882b',
        target=hd2.vehicle('EXO-45 Patriot Exosuit'):weapon('right_gun'):attack('primary'):projectile_source().target,
        field=hd2.fields.attack.projectile,
        expect=hd2.vehicle('EXO-45 Patriot Exosuit'):weapon('right_gun'):attack('primary'),
        value=hd2.attack_output('output/v1/projectile/las-58-talon'),
    }
}) end)
add(function() return hd2.ensure({
    transaction={
        id='row-640d795e8852eabf2c6fc58d',
        target=hd2.attack_output('output/v1/projectile/las-58-talon'),
        changes={
            {field=hd2.fields.projectile.impact_explosion,expect='none',value=hd2.attack_output('output/v1/projectile/gl-21-grenade-launcher'):impact_explosion()},
        },
    }
}) end)
add(function() return hd2.ensure({
    transaction={
        id='row-00068f8a4de39144fbc9368b',
        target=hd2.attack_output('output/v1/projectile/s-11-speargun-spare-twin'),
        changes={
            {field=hd2.fields.presentation.mode_label,expect='none',value='stun'},
            {field=hd2.fields.presentation.mode_icon,expect='default',value='auto'},
        },
    }
}) end)
return operations
