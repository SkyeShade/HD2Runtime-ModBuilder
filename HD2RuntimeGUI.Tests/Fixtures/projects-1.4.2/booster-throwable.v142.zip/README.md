# Booster Throwable



By ModBuilder 1.3.1.

Requires Bingus Shared Loader v15+ / API 1 and HD2Runtime 0.27.0+ / API 1; install dependencies separately.

Install this gameplay ZIP through your mod manager after installing both dependencies.
