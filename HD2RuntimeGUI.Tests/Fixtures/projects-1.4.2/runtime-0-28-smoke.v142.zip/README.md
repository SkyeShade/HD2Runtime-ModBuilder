# Runtime 0.28 Smoke



By Smoke.

Requires Bingus Shared Loader v15+ / API 1 and HD2Runtime 0.28.1+ / API 1; install dependencies separately.

Install this gameplay ZIP through your mod manager after installing both dependencies.
