local hd2=require('mods/skyeshade/hd2runtime')

local generated={}

-- Custom Lua: src/addon.lua (hand-written; ModBuilder copies it unchanged)
local function addon(...)
-- Custom HD2Runtime Lua for this mod. ModBuilder's generated modifications are registered before this runs.
-- `hd2` is already required; the event API reference and snippets are in ModBuilder's Custom Lua page.
local mod = hd2.mod()
end
addon()
return generated
