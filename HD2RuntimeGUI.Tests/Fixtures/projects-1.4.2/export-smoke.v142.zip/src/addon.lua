local hd2=require('mods/skyeshade/hd2runtime')

local generated={}
local function add(build)
    local ok,operation=pcall(build)
    if ok then generated[#generated+1]=operation
    else print('[ModBuilder] operation skipped: '..tostring(operation)) end
end
add(function() return hd2.ensure({
    patch={
        id='gui-object-bb7d8a6405f21e8d4b4eb22a',
        target=hd2.weapon('AR-23 Liberator'),
        field=hd2.fields.weapon.fire_rate,
        expect=640,
        value=720,
    }
}) end)

-- Custom Lua: src/addon.lua (hand-written; ModBuilder copies it unchanged)
local function addon(...)
-- Custom HD2Runtime Lua for this mod. ModBuilder's generated modifications are registered before this runs.
-- `hd2` is already required; the event API reference and snippets are in ModBuilder's Custom Lua page.
local mod = hd2.mod()
end
addon()
return generated
