# Runtime diagnostics

Two cheap diagnostics help tell whether HD2Runtime is involved when a large mixed mod setup loses frames. They do
not assume Runtime is the cause, and they do not prove it isn't. Both live in `runtime/diagnostics.lua` and are
reachable through `hd2.diagnostics`. A third, `hd2.diagnostics.operations()`, lists every registered operation and
how it ended (see [Registered operations](#registered-operations-hd2runtime-0281)).

## Write conflicts (always on)

An `hd2.ensure` keeps its target at the value it wrote. It re-checks only the owned bytes, on a verification interval
that backs off from 60 s to 10 minutes while the target stays stable. When the check finds the owned bytes changed
while their allocation is still the reviewed one (drift reason `target value drifted`), something else wrote them.
Runtime then re-applies, and counts the event for that operation.

After **3 external changes within the operation's window** (five of its verification intervals, at least 10 s),
Runtime logs one line:

```
[HD2Runtime] possible write conflict: operation gui-object-3d9ff4833c24584a039f823f (player_weapon SG-20 Halt:
weapon.fire_rate) externally changed and re-applied 3 times in 120.0 s; another mod may be writing the same memory
```

- **What the line names.** The operation id, its target (resource, weapon or stratagem, attack role or path) and up
  to four fields, the count and the time span.
- **No spam.** The next warning for that operation waits a full window.
- **Not counted.** A game reallocation (`owner allocation changed`, `target region changed`) is not a write conflict:
  it is the game rebuilding its data, and Runtime re-resolves it the normal way.
- **Cost.** The counting runs only on a detected drift, never per frame.

`hd2.diagnostics.write_conflicts()` returns every operation that saw external changes, most first:
`{operation, target, externalChanges, warnings, windowSeconds}`.

**Reading it.** Two mods writing the same bytes fight: each re-applies its own value. Runtime's side of the fight is
bounded by its verification interval, so it re-applies at most once per interval. A self-contained memory mod that
rewrites every frame costs whatever that mod costs. If a report shows conflicts, remove one of the two mods (or one of
the two edits); if it shows none, the FPS loss is not Runtime fighting another writer.

## Conflicts between mods (CONFLICT lines)

A guarded write replaces only the reviewed vanilla value or bytes that already hold its own desired value. Anything
else stops the operation (`code=CONFLICT`); it never overwrites another writer's value. Since 0.30 the reason also
says who holds the bytes and who else uses them (`core/shared_records.lua`):

```
[HD2Runtime] ensure stun stopped code=CONFLICT reason=CONFLICT: status.duration is neither expected nor desired
(target support_weapon ARC-3 Arc Thrower primary_status_37; expected 1.5 (1.5); desired 3 (3); observed 2; ...;
held by mods/carol/sentries ensure stun (stratagem A/ARC-3 Tesla Tower status.duration = 2); the same native record
is also used by stratagem A/ARC-3 Tesla Tower status.duration)
```

- **held by** names the mod, operation kind and id, target and value of the HD2Runtime operation that applied the
  observed bytes. Two mods edited one native value with different values: keep one of the edits, or give both the
  same value (equal values compose: the second finds its value already there).
- **last applied by ..., changed since outside HD2Runtime** means a Runtime operation wrote these bytes and something
  that is not a Runtime patch, transaction, plan or ensure changed them afterwards.
- **no HD2Runtime patch, transaction, plan or ensure applied these bytes this session** means the observed value
  came from another program writing game memory, or from a mod whose own data files change that value.
- **the same native record is also used by** lists every other catalogued target (any catalogue: player, support and
  mounted weapons, stratagems, backpacks, vehicles, throwables, enemies, boosters) that uses the same settings row or
  component record. Each catalogue lists only its own consumers in `shared with N other weapons`; this part adds the
  rest. Example: the ARC-3 Arc Thrower's stun status row is the A/ARC-3 Tesla Tower's.

**Unlisted sharing.** One record is marked unshared by its catalogue although another catalogue uses it: the FLAM-66
Torcher's DamageInfo row is the AX/FLAM-75 Hot Dog drone gun's. A Torcher edit stays accepted without `allow_shared`
(the published contract), and its registration logs one line naming the other user:

```
[HD2Runtime] ensure torch (mods/x): damage.standard_damage of player_weapon FLAM-66 Torcher is in a native record that
vehicle_weapon AX/FLAM-75 Hot Dog / gun also uses; its catalogue lists no other user, so this edit changes it too,
and another mod editing it conflicts
```

Operation ids are per mod: two mods may both use `op-1`, and both operations run. The CONFLICT line names the holding
operation's mod, so the two stay distinguishable in the log.

## Stray entity map rows (0.30.3)

Every typed write reads the game's entity map, the table that says which entity owns which component records. When
one row of it is not as reviewed, usually because another mod changed that entity, the log says so once per session:

```text
[HD2Runtime] entity map row 329 (resource 0xC85F576D5E086147) is not as reviewed: writes to it are refused, every other
write goes ahead (invalid/ambiguous bounded pointer: entity map row 329 ...)
```

- Only writes to that entity are refused, with the same reason. Before 0.30.3, one such row refused every typed write
  of every mod (`VALIDATION_FAILED ... invalid/ambiguous bounded pointer`), even writes to other weapons.
- The row's resource names the entity (`0xC85F576D5E086147` is the LAS-12 Sai). Look for a mod that changes it.

## Values changed by mods outside HD2Runtime (0.31.0)

Mods that are not HD2Runtime mods change game values too: data-file mods (patched game archives) and programs that
write game memory. HD2Runtime cannot see them, only their values. A value that is neither HD2Runtime's reviewed
(vanilla) value nor bytes any HD2Runtime patch, transaction, plan or ensure applied this session is **owned by an
unknown mod**. HD2Runtime leaves it as it is and refuses writes to that value only. Every other value, the rest of the
same record included, stays writable.

- **The log says so once per value:**

  ```text
  [HD2Runtime] FOREIGN VALUE: stratagem A/G-16 Gatling Sentry turret.yaw_speed is 95, not HD2Runtime's reviewed 80:
  owner unknown mod (a mod outside HD2Runtime: a data-file mod or another program writing game memory). HD2Runtime
  leaves it as it is and refuses writes to this value only; every other value is unaffected
  ```

- **The refused operation** keeps `code=CONFLICT`, unchanged for older mods. Its result also carries
  `owner='unknown'` and `foreign=true`, its reason ends with `owner: unknown mod, not HD2Runtime`, and the log line
  reads `REJECTED code=CONFLICT owner=unknown ...` (`ensure ... stopped code=CONFLICT owner=unknown ...` for an
  ensure). A conflict with another HD2Runtime mod has no `owner` and names the holder (`held by ...`, above).
- **Only tracked bytes.** A value with no native record identity (an attachment delta row: an ammunition, a muzzle)
  cannot be traced to its writer, so a conflict there is a plain `CONFLICT` and `hd2.inspect` says `changed`, never
  an unknown mod's.
- **`hd2.diagnostics.foreign_values()`** lists every value found so this session, in the order found:
  `{target, field, observed, expected, owner='unknown', seen}`. At most 256 are kept.

### Component tables another mod moved

The game keeps one pointer per component type (WeaponHeat, BeamWeapon, WeaponMagazine, ...) to the table its
lookups read that component's records from. In vanilla that table is the one in the game's entity data, which is the
table HD2Runtime reads and writes. A mod can copy a table and point the game at its copy. The game then reads the
copy, and a write to the original has no effect and raises no error.

This is the cause of the LAS-12 Sai report: "editing the Heat Per Shot and Cool Per Sec for the LAS-12 Sai has no
effect", and "after changing a few values the overheat mechanic for the SAI gets wonky". True Lasgun Beam Overhaul
points the game at its own copies of the BeamWeapon, WeaponHeat and WeaponMagazine tables, and it runs its own Sai
heat logic every frame. With it installed, the Sai's heat values are that mod's, not the ones HD2Runtime edits.

Since 0.31.0, before every typed write to a component record, HD2Runtime checks that the game reads that component
from exactly the table it is about to write (`core/component_tables.lua`). The check is read-only and runs on every
entity capture. If the pointer differs:

- Only writes to that component are refused, as a `CONFLICT` with `owner='unknown'`. Every other component of the same
  weapon goes ahead, for example the Sai's ergonomics (WeaponData) or fire rate (ProjectileWeapon), and so do all
  other weapons and values.

  ```text
  CONFLICT: the game reads its WeaponHeatComponentData table from another place (another mod moved it); HD2Runtime
  leaves it alone, writes to WeaponHeat records are refused and every other component goes ahead (owner: unknown mod,
  not HD2Runtime)
  ```

- The log says so once per component per session:

  ```text
  [HD2Runtime] COMPONENT TABLE MOVED: the game reads its WeaponHeatComponentData table from another place, not the
  entity file's own table (another mod moved it, e.g. one that rebuilds laser weapons): HD2Runtime leaves it alone and
  refuses writes to WeaponHeat records only; every other component and value goes ahead. owner: unknown mod
  ```

- `hd2.inspect` reports each field of that component as `foreign`, owner `'unknown'`, with no value.
  `hd2.diagnostics.foreign_values()` lists the table once (`target='WeaponHeatComponentData table'`).
- If the other mod points the game back at the original table, writes go ahead again on the next capture.
- If the pointer cannot be read, every component of that capture is refused as `TARGET_UNAVAILABLE` (transient: the
  operation waits and retries).

Proof: `research/docs/entity-component-table-pointers.md`. The pointer is `[game.dll + 0x346BF98] + 0xF12478 + 8 x the
component index`. The constructor stores the entity manager there, and the entity file loader is the only code that
writes it. Every lookup of all 43 components HD2Runtime uses reads through it. In the retained vanilla snapshots
every pointer is the table HD2Runtime writes. The code pins (exact bytes) are checked once per loaded game.dll, after
the build fingerprint.

### Asking before writing: `hd2.inspect`

A stats editor needs to know which values it may edit before it registers anything. `hd2.inspect` runs the same
guarded resolution a patch runs (discovery, ownership, identity, the reviewed expected bytes), read only: it writes
nothing and changes no page protection.

```lua
local job=hd2.inspect({target=hd2.stratagem('A/G-16 Gatling Sentry'):deployed_entity():turret(),
    fields={hd2.fields.turret.yaw_speed, hd2.fields.turret.pitch_speed},
    on_result=function(result)
        for _,f in ipairs(result.fields)do print(f.field, f.state, f.owner, f.value)end
    end})
-- or poll: job.status == 'complete', job.result.by_field[hd2.fields.turret.yaw_speed].state
```

- **Arguments:** `target` is a typed handle. `fields` holds one to 64 field ids. Each entry is a string, or
  `{field=id, expect=value}` when the field's reviewed value cannot be read from the target's `describe()` (a
  reference field, for example). `on_result` is optional.
- **When it finishes:** the job's status becomes `complete`. `job.result.fields` lists one entry per field, in
  request order, and `job.result.by_field[id]` gives the same entries by id. Each entry is
  `{field, state, owner, operation, value, vanilla, bytes, reason}`.
- **Cost:** one guarded resolution per field, spread over frames like any write's. Inspect the fields a page shows,
  not every catalogue.
- **Bad requests:** a request that is not valid (no typed target, no fields, more than 64, an unknown option)
  raises.

| `state` | Meaning | `owner` |
|---|---|---|
| `vanilla` | the reviewed value (the catalogue's `currentDefault`) | |
| `runtime` | bytes an HD2Runtime operation applied; `operation` is its id | that operation's mod |
| `foreign` | owned by an unknown mod: writes to it are refused. Show it read-only. | `'unknown'` |
| `changed` | a structural part this value depends on (a graph link, a status slot, a native array) is not as reviewed, and no writer can be named; writes to it are refused | |
| `unavailable` | the target could not be resolved now (`reason`), e.g. its data is not loaded yet | |
| `invalid` | the request names no exposed field, or no reviewed value was found (`reason`) | |

`value` is the live value when the field stores it plainly (the reviewed value reads back from its own bytes), else
nil. `bytes` is the live value's bytes in hex.

### Stratagem graph links: a changed link refuses only the values below it

A stratagem's projectile, damage, explosion, status, arc and beam rows are reached through links: the payload
projectile list, a projectile's damage and explosion rows, a DamageInfo row's status slots. Before 0.31.0, every write
to a stratagem's attack checked **every** link of its graph. One link another mod had changed, for example a status
slot type a data-file mod swapped, refused every attack value of that stratagem, and so did a status swap by another
HD2Runtime mod. Now a write checks the chain from the root to its own row: every node above it and the link into it.
A changed link refuses only the values below it, which are the rows the stratagem may no longer reach.

Why this is safe (`domains/stratagem_writes.lua` `graph_paths`):
- A settings row is located by its own identity (group, row and kind in the settings table, `selected_record`), and
  that is still checked before every write. The links never locate it; they only prove that this stratagem reaches
  the row the reviewed way.
- That proof is still made in full for the row written: its whole chain from the payload root.
- The root link (the payload projectile list, the Eagle payload, the orbital's projectile or damage link) is still
  checked for every write.
- A component-backed value (turret, weapon, shield records) is located and proven through the entity catalogue, so
  it needs no graph link.
- If a settings row names no path in this stratagem's graph, every link is checked, as before. Every one of the 1,178
  writable settings fields of the current catalogue names its path.
- Test: `tests/test_foreign_values.py` swaps the A/ARC-3 Tesla Tower's status slot on a copy-on-write overlay of the
  retained snapshot. The status row's duration is refused (`damage status link changed`); the DamageInfo row's damage
  and the arc's range apply. Before, both were refused.

## Telemetry (off by default)

```lua
hd2.diagnostics.telemetry({enabled=true, report_seconds=60})
```

When enabled, every `report_seconds` Runtime logs:

```
[HD2Runtime] telemetry 60 s: update avg 0.071 ms p95 0.12 p99 0.31 max 1.20 (3600); ensure byte-check avg 0.02 ms
p95 0.03 p99 0.05 max 0.08 (40); event polling avg 0.05 ms ...; active ensures 12; re-applications 0
```

- **update** is the whole Runtime per-frame update.
- **ensure byte-check** is one steady-state verification.
- **event polling** is the event system's tick.
- **Samples.** They come from the durations the metrics module already measures, kept in fixed 512-entry rings.
- **Percentiles** are computed only when the report is written.
- **Disabled cost.** One boolean test per timed section and per update; nothing is sampled or allocated.
- **Precise clock.** Timing needs the game's precise clock (in game); offline, the report says so.

`hd2.diagnostics.telemetry()` without arguments returns the state and the running interval's sections.

## Registered operations (HD2Runtime 0.28.1+)

`hd2.diagnostics.operations()` returns every operation registered this session, in registration order, including
the ones Runtime refused. An addon that keeps no handle, or registers operations in a callback, is covered too:

```lua
for _, op in ipairs(hd2.diagnostics.operations()) do
    -- op.kind ('patch'|'transaction'|'plan'|'ensure'), op.id, op.mod, op.sdk, op.sdk_source,
    -- op.status ('rejected', 'complete', 'waiting', 'unavailable', ...), op.result ('APPLIED', 'REJECTED', ...),
    -- op.code, op.error, op.runs (ensure), op.legacy
end
```

- **`status` / `result`.** `status='rejected'` is a refusal: at registration (logged as `<kind> <id> rejected:
  <reason>`) or when applying (for example `CONFLICT`). `unavailable` and `disabled` are option-bound operations that
  are switched off or have no Mod Options Menu. An ensure that applied has `runs >= 1` and `result='APPLIED'`
  (or `ALREADY_DESIRED`).
- **`sdk` and `sdk_source`.** The SDK version the registering mod declares, and where it came from: `wrapper` (read
  from the mod's addon wrapper), `mod` (remembered for that mod resource) or `unknown`.
- **`legacy`.** `{target, field, acknowledgement, since}` for each field this operation wrote without an
  acknowledgement that a later SDK added (docs/legacy-sdk-compatibility.md). Each one is also logged once when the
  operation registers.

The list is a copy; the entries are read when it is called. At most 4096 registrations are kept (the oldest are
dropped first; the second return value is `{dropped = n}`).

## Every mod's options (r51)

`hd2.diagnostics.options()` returns every options page (`kind = 'menu'`) and every mod's script values
(`kind = 'script'`) with their owner, their options' current values and the ensures bound to them
(docs/options.md "Every mod's options").

## Which mod is slow (always on, quiet; 0.30.0)

`hd2.diagnostics.performance()` returns the CPU time of every mod, plus the Runtime's own work, the most time first.
That covers every call into a mod and every update the Runtime runs for its operations. Each entry has the total,
the call count, the slowest call and the last 10 s window.

A single call of 8 ms or more, or a mod averaging 1 ms or more per update over 10 s, logs a `PERFORMANCE:` line
naming the mod and the callback. Details and thresholds are in [runtime-performance.md](runtime-performance.md#which-mod-is-slow-0300).

## Asking for a report

A user with a large setup can:
1. add a small mod that enables telemetry;
2. play one mission;
3. send `HD2Runtime.log`.

The report and any write-conflict lines show whether Runtime's update is expensive or is fighting another mod.
