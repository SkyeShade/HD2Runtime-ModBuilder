# Screen overlays (`hd2.ui.overlay`)

A mod draws rectangles and text over the game through the Runtime's own GUI path: the world, layers, retained
primitives and engine temporaries are handled for it. Implementation: `runtime/mod_overlay.lua` on
`runtime/engine_gui.lua`; API: `api/ui.lua`. **Offline-tested only; not live-tested yet.**

```lua
local hd2 = require('mods/skyeshade/hd2runtime')
local overlay = hd2.ui.overlay()                 -- your mod's overlay 'main'; {id = 'hud2', layer = 1011} for more
local score = 0

overlay:draw(function(d, dt)                     -- every frame while shown: describe the whole frame
    local s = d.scale                            -- the screen against 1920 x 1080
    d:rect(40 * s, 40 * s, 320 * s, 90 * s, {10, 12, 14, 210})
    d:rect(40 * s, 40 * s, 320 * s, 3 * s, '#C8B43C', 1)
    d:text('STRATAGEM HERO', 56 * s, 52 * s, {size = 26 * s, font = 'title', z = 2})
    d:text('SCORE ' .. score, 56 * s, 90 * s, {size = 20 * s, colour = {200, 200, 196}, z = 2})
end)

hd2.input.bind('arcade.toggle', {key = 'Home', on_press = function()
    if overlay:status().visible then overlay:hide() else overlay:show() end
end})
```

## Drawing

| call | draws |
| --- | --- |
| `d:rect(x, y, w, h, colour, z)` | a filled rectangle; `(x, y)` is its top-left corner |
| `d:text(text, x, y, {size, colour, font, align, z})` | one line; `(x, y)` is its top-left corner (top-centre / top-right with `align = 'center' / 'right'`) |
| `d:text_width(text, size, font)` | the width in pixels, with the same metrics |
| `d:can_draw(text, font)` | whether every character can be drawn this frame (see [Other scripts](#other-scripts-chinese-japanese-korean-russian-0310)) |
| `d:wrap(text, width, {size, font, lines})` | the lines of text no wider than `width`, measured as `d:text` draws them |
| `d:image(image, x, y, w, h, {colours, colour, z})` | one of the mod's own images (`hd2.resources.image`), or one of the game's own HUD icons (`hd2.resources.game_icon`, docs/game-icons.md); `(x, y)` is its top-left corner (r50) |

- **Coordinates** are GUI pixels with the origin at the **top-left**, y down (the same corner as
  `hd2.input.mouse()`; `overlay:mouse()` maps the cursor into overlay coordinates). `d.width`, `d.height` are the
  screen; `d.scale` = min(width / 1920, height / 1080) sizes a layout made at 1080p.
- **Colours**: `{r, g, b[, a]}` 0-255 (alpha defaults to 255) or `'#RRGGBB'` / `'#RRGGBBAA'`; default white.
- **Fonts**: `'body'` (FS Sinclair, the loadout screen's typeface) and `'title'` (FS Sinclair Medium), shipped in the
  Runtime's archive; `'mono'` is the engine's `monaco`. A role whose font is not loaded falls back to `monaco`.
  Text is 1-512 printable bytes (UTF-8; 0.30.3 and earlier: 160), size 4-256 px. Characters the font lacks are drawn
  in the game's own language fonts when the game has them loaded (next section), else as `?`.
- **Text placement (r50 calibration).** The Runtime's FS Sinclair fonts draw their glyphs 0.41 x size below the
  baseline `Gui.text` is given. Measured live on 2026-10-07 (HD2Runtime Editor at 3838 x 2158): text at sizes 12-22
  landed 0.37-0.45 x size low. The font build measures glyph records from the baseline but writes the header offset
  -descent x 0.75, the monaco convention for records measured from the line bottom (`scripts/hd2_font.py`); the rest
  is likely the distance-field padding. The overlay lifts FS Sinclair text by `0.41 x size`
  (`runtime/mod_overlay.lua` `M.TEXT_DROP`), so `(x, y)` is the line's top-left as documented. The custom stratagem
  panel and the other Runtime GUIs pass baselines directly and are not corrected yet.
- **Layers**: every overlay has a band starting at its `layer` (default 1011); an item's `z` (default 0) is added.
- **Wrapping** (`d:wrap`, and the Runtime's own panels): lines break at spaces and between any two CJK characters
  (ideographs, kana, Hangul, CJK punctuation); closing punctuation (`、。，！？」` ...) never starts a line; a word wider
  than a line is cut between characters, never inside a UTF-8 sequence.
  The engine orders all GUIs of one world by layer, and the layer's depth key is `0.1 * (1023 - layer) / 1023`
  (exe 0x2693E3), so 1023 is the top: an item past it is refused. The default band sits above the native HUD's own
  top layers (991-1018 are used by native GUIs; the Runtime's slot overlays use 940, its panel 920-944).
- Items are clipped to the screen; an item entirely off screen is dropped. Invalid items (not finite, a bad colour,
  a control character, a layer past 1023, an unknown font, more than 1024 items a frame) are **refused, never passed
  to the engine**: `overlay:status()` counts them (`refused`, `first_refusal`).

## What the overlay does for you

- **The world.** A screen GUI in the game's **Ui World**, the world the native HUD and loadout screen draw their GUIs
  in, where the Runtime's slot overlays and panel are seen live. `Application.main_world` is the Game World and
  draws under the whole UI composite. The Ui World is found again every frame: when the game replaces it (ship to
  mission and back) or the resolution changes, the GUI is opened again there.
- **Retained primitives.** Each item keeps one engine primitive. A frame calls the engine only for what changed:
  `Gui.update_rect`, `Gui.update_text` for a changed item, `Gui.rect` / `Gui.text` for a new one, `Gui.destroy_*` for
  one that is gone. An unchanged frame makes no engine call. The argument orders are read from the engine's own
  bindings (exe `0x3E5860` -> `0x3E54D0`: `update_text(gui, id, text, font, size, material, position, color)`, the
  parser `Gui.text` uses with the id second; `0x3E2040` / `0x3E58E0` / `0x3E2EB0`: `destroy_rect / destroy_text /
  destroy_bitmap(gui, id)`).
- **Temporaries.** Each pass runs between `Script.temp_count()` and `Script.set_temp_count(n)`, so the `Vector2`,
  `Vector3` and `Color` values it builds never move the engine's temporaries ring on. In this build both take one
  integer (exe `0x490150`: the byte position in a 1 MiB ring; `0x490270` sets it), not the three counts of older
  engines.
- **Validation.** The engine bindings check nothing (a wrong value most likely crashes); every value is checked
  first.
- **Failures.** A draw function that raises is a frame-callback failure of your mod (logged with the mod id; 25 in a
  row disable it) and its items are hidden on that frame. An engine call that fails closes the GUI (logged once per
  reason); the next frame opens it again.

## Limits

- **Native menus draw above.** The game draws its Noesis UI (menus, the map, the loadout grid and cards) after every
  world GUI, so no layer puts an overlay above them.
- **Input is not consumed.** An overlay that takes keys (`hd2.input.pressed`) shares them with the game; see
  [events.md](events.md#input-blocking-not-available).
- **Images are icon masks.** `d:image` draws through the game's icon material: R, G and B masks coloured by
  `colours`, never true colour (a raw picture shows as a silhouette; docs/custom-images.md). Vanilla stratagem icons
  are atlas sprites that `Gui.bitmap` most likely cannot show, and booster icons exist only as Noesis XAML: neither is
  offered.
- Visibility is the user's observation only: an engine call that succeeds (an id returned) does not prove pixels
  appeared.

## API

- `hd2.ui.overlay(opts)`: the calling mod's overlay `opts.id` (default `'main'`), created on first use and the same
  object afterwards. `opts`: `{id, layer = 1..1023 (default 1011), visible = true, owner}`.
- `overlay:draw(fn)`: `fn(d, dt)` describes every frame. `overlay:show()`, `:hide()`, `:close()` (removes its
  primitives, its GUI and its frame callback), `:mouse()`, `:text_width(text, size, font)`, `:status()` (`{owner, id,
  state = 'waiting' | 'drawing' | 'hidden' | 'error' | 'failed' | 'closed', reason, layer, visible, width, height,
  scale, items, frames, engine_calls, opened, refused, first_refusal}`).
- `hd2.ui.overlays()`: every overlay's status. `hd2.ui.colour(c)`: a colour as `{r, g, b, a}`, or nil.
- `hd2.ui.can_draw(text, font)` and `hd2.ui.game_fonts()`: see [Other scripts](#other-scripts-chinese-japanese-korean-russian-0310).
- `overlay:free_cursor(on, {camera = true})` and `hd2.ui.cursor()`: see [The cursor](#the-cursor-experimental-r50).
  `status()` also reports `waiting_images`, `image_reason`, `cursor`, and for game fonts `game_fonts` (the keys drawn
  last frame), `waiting_text` and `text_reason`.

## Other scripts: Chinese, Japanese, Korean, Russian (0.31.0)

```lua
local description = '...'                        -- a translated paragraph
overlay:draw(function(d)
    local title = hd2.ui.can_draw('模组设置') and '模组设置' or 'MOD SETTINGS'   -- fall back when it cannot be drawn
    d:text(title, 40, 40, {size = 24, font = 'title'})
    for i, line in ipairs(d:wrap(description, 400, {size = 18, lines = 4})) do
        d:text(line, 40, 70 + 24 * (i - 1), {size = 18})
    end
end)
```

The Runtime's FS Sinclair fonts hold ASCII, Latin-1, the call-in arrows and a few punctuation marks. Any other
character is drawn in **the game's own font for that script**: nothing is shipped (the Runtime ZIP carries one
288-byte material per font) and nothing is written to the game. The game loads only its selected language's font;
the Runtime loads the one a text needs, in any game language (below).

| key | script | loaded by the game when its language is | characters |
|---|---|---|---|
| `default` | Latin extras | English, German, French, Italian, Spanish, Portuguese, Polish (the game's codes us, gb, bp, de, es, fr, it, ms, pl, pt) | Latin-1, 23 Latin Extended-A (Polish ...), 13 Cyrillic letters |
| `ru` | Cyrillic | Russian | the Russian alphabet |
| `zh_hans` | Simplified Chinese | Simplified Chinese | 2809 ideographs |
| `zh_hant` | Traditional Chinese | Traditional Chinese | 2815 ideographs |
| `ja` | Japanese | Japanese | kana, 1781 ideographs |
| `ko` | Korean | Korean | 1202 Hangul syllables |

- **In any game language** (0.31.0, issue #8). The game loads only its selected language's font package (game.dll's
  language records name one per language). Text with characters neither its font nor a loaded game font has asks for
  the game font package that has the most of them (then the next; at most two per text), through the same
  reference-counted package system the Runtime loads item packages with (`core/assets`: proven native pins, a
  catalogued package, residency read back, kept for the session; the six font packages are bundles of the build's
  `bundle_database.data`). Until it is loaded those characters show `?`; then they draw (the per-frame residency proof
  picks the font up within a second). One request per font per session, logged once
  (`ui fonts: loading the game's Simplified Chinese font package ...`); `hd2.ui.can_draw` asks too, so a mod that
  checks its text first starts the load. A Chinese font package is about 25 MB of GPU memory per weight.
- The fonts are **the characters the game itself uses**, not whole scripts: a rare character outside them shows as
  `?`. **Greek is not available**: no game font has it.
- `hd2.ui.can_draw(text, font)` (and `d:can_draw` inside a frame) tells before drawing: `true`, or `false`, the number
  of distinct characters that would show as `?` and up to three of them. `hd2.ui.game_fonts()` lists the fonts:
  `{key, label, languages, glyphs, resident, reason}`. `hd2.ui.unsupported(text, font)` (0.31.0) counts only the
  characters no font can ever draw (in no game font at all): the number of distinct characters that always show as
  `?`, and up to three of them; 0 means everything draws once its font is loaded. A translation tool should warn on
  this, not on `can_draw` (which is false for a moment while a font package loads).
- **How it is drawn.** Text is split into runs: the role's font draws every character it has, exactly as before (text
  it fully covers is one item, unchanged); a character it lacks goes to a loaded game font that has it (a space
  between two such characters stays with them); each run is one engine text on the same baseline. A game font is an
  engine FONT resource named by its 64-bit hash (`IdString64`; Gui.text reads a non-string font that way, exe
  `0x3E51D7`), drawn through a Runtime-owned material (`hd2runtime_fonts/game/<key>`: monaco's font material, the same
  MSDF text shader the game's font materials compile to); that material's instance in the overlay's GUI is pointed at
  the font's atlas with `Material.set_texture`, the technique the game icons proved live. Widths, alignment and
  wrapping use the fonts' own advances and kerning, generated from the game files into `domains/ui_fonts_<key>.lua`.
- **Safety.** The engine uses a text's font without checking it exists, so a game font is drawn only when its font, its
  atlas and the Runtime material are all proven loaded in the same frame (the resource manager, read-only); a run
  whose font is not loaded is skipped (`status().waiting_text`). When a font in use unloads (a language switch), the
  GUI is closed first, so no material instance keeps naming its atlas, and opened again without it.
- **The Runtime's own panels** use the same path (`runtime/game_text.lua`): the custom stratagem panel's details and
  tooltip (a custom stratagem's name, description and traits) and the alert card. Each re-proves its game fonts every
  frame it stays on screen and is drawn again without one that unloaded.
- **Live-proven** (2026-10-09, development build 0.30.4-dev3 of 0.31.0, `proof/GameFontTextProof`): each language's own text drew in the game's
  font with the game in that language; characters a font only lists (other languages' names) are left out
  (`hd2_font.undrawable_glyphs`). **Not live-tested yet:** loading another language's font package on demand, and the
  panels. Research: game-font-text (build F5FEE03DCFDB).

## Images (r50)

```lua
local logo = hd2.resources.image('logo')           -- images/logo.png in the mod project (256 x 256)
overlay:draw(function(d)
    d:image(logo, 40 * d.scale, 40 * d.scale, 64 * d.scale, 64 * d.scale,
        {colours = {r = '#45ACC8', g = {255, 255, 255, 238}}})
end)
```

- An image is drawn only when its texture, material and sprite are proven loaded (`image_resources.family`; checked
  again every 60 frames until it is). Until then it is skipped and `status().waiting_images` counts it.
- `colours = {r, g, b}`: the colours of its R, G and B masks (the icon material's c0-c2; the alpha is the layer's
  strength). The default is white R and G and the native 0.2 black shadow on B; c3 is always zero (the BC1 texture's
  alpha is about 1 everywhere, so a non-zero c3 would flood the quad). `colour` is the vertex colour (tint, alpha).
- One material instance per image per GUI: every draw of one image in one overlay shares one colour set. A second
  set in the same frame is refused (`one colour set per image per overlay`); a new set in a later frame recolours it.
- An image partly off screen is dropped (a bitmap is never squashed).

### The game's own HUD icons

```lua
local patriot = hd2.resources.game_icon('stratagem', 'EXO-45 Patriot Exosuit')
overlay:draw(function(d) d:image(patriot, 40, 40, 64, 64, {colours = {r = '#FF6E5C'}}) end)
```

Every stratagem and booster HUD icon, drawn from the game's own atlas pages with the game's own materials: nothing is
shipped and nothing is written (docs/game-icons.md). Stratagem icons take the same `colours`; booster icons are drawn
in their own colours. Differences from a mod image:
- one icon may be drawn in several colour sets in one overlay (each extra set borrows another icon material);
- an icon is drawn only while its atlas page is loaded: booster icons are not during a mission;
- when a page or material in use unloads, the overlay closes its GUI and draws again without that icon.

## The cursor (experimental, r50)

`overlay:free_cursor(true)` frees the mouse cursor from the camera while the overlay is shown: through the engine's
own Lua Window API it shows the cursor (`Window.set_show_cursor(true)`), stops clipping it to the window
(`set_clip_cursor(false)`) and drops the mouse focus (`set_mouse_focus(false)`), the raw mouse input the camera turns
from. `{camera = false}` keeps the focus. Hiding or closing the overlay, or `free_cursor(false)`, gives it back: the
values the getters reported before the first hold are restored (`runtime/mod_cursor.lua`).

**Over a game menu the focus is kept (0.30.2).** When the game already shows its own cursor at the first hold (a
terminal, the loadout screen, the pause menu), its menu already keeps the camera still, so only the cursor is freed and
the engine keeps reading the mouse, wheel included: `hd2.input.wheel()` works there without the native hook. A wheel
turn may also scroll the game menu underneath. If the game hides its cursor during the hold (the menu closed), the
focus is taken as usual, and the release restores what the game had then. `hd2.ui.cursor().game_menu` tells which.

- Each setter is called only when its getter (`Window.show_cursor()` etc., no argument) reports otherwise, so a quiet
  frame costs three getter calls. Every value passed is a boolean; the first engine error turns capture off for the
  session (logged once, `hd2.ui.cursor().disabled`).
- **Not live-tested.** The functions are registered (their names are in the engine's Window string table of the
  retained snapshot), but no build called them before r50. The live test checks: is the cursor visible and free in a
  mission and on the ship; does the camera stop; does a click still fire the weapon (keys and clicks are still not
  taken from the game); is everything restored after closing, alt-tab and a mission change.

Tests: `tests/test_ui_overlay.py` (a recording fake of the engine GUI API).

## The mouse wheel (experimental, r51)

`hd2.input.wheel()` is the wheel this update tick in notches (+ up, - down; fractions for smooth wheels), 0 when it
did not move. The editor's scroll lists read it once per frame.

**Turning the native hook off (0.30.2).** The hook is on by default. In the mod manager (Arsenal, Echelon) the
runtime's option has a pick-one choice: *Mouse wheel hook on* (the default) or *Mouse wheel hook off (may fix
GameGuard crashes)*. "Off" also deploys a one-resource archive, `hd2runtime/settings/wheel_hook_off`, whose presence turns the hook off for the
session. GameGuard error 1015 ("Suspicious program detected") was reported with 0.30.x, and a window hook running
generated code is what anti-cheat looks for. Off, nothing native is built or installed: `hd2.input.wheel()` reads
the engine axis only (it works over a game menu, see The cursor), `hd2.input.block()` returns `false` and the
reason, and `hd2.input.wheel_status().native` is `false`. The API is unchanged, so mods need no update.
`hd2.input.wheel_status().install_option` is `'hook_on'` or `'hook_off'`; with `'hook_off'`, `notice` is a message a
mod can show the player ("GameGuard safety: mouse wheel scrolling is off in mod windows ...").

- `GetAsyncKeyState` cannot see the wheel, and the engine's `stingray.Mouse` `wheel` axis read nothing while the
  overlay held the mouse focus (live test of r50). Two sources are sampled once per tick while someone queries:
  the engine axis, and a `WH_GETMESSAGE` hook on the game window's thread counting `WM_MOUSEWHEEL` and the wheel
  of `WM_INPUT` raw mouse input (`runtime/mouse_wheel.lua`).
- **The hook procedure is native code, not Lua.** The game pumps its window messages on another thread than the one
  running Lua (live r51: window thread 65780, Lua thread 51232), so a Lua callback there would run Lua on a foreign
  thread. `M.hook_code` assembles about 200 bytes of x64 into a page the Runtime allocates once and never frees: it
  adds `WM_MOUSEWHEEL` deltas to one counter and raw-input wheel deltas to another (`GetRawInputData` on the
  message's own handle, read-only), and always returns `CallNextHookEx`. Lua reads the counters once per tick (raw
  input wins when both saw the same turn). Nothing is consumed, so the game still scrolls its own menus.
- It is removed one second after the last query (the pages stay); a failed install is retried at most every two
  seconds (r51 retried every frame and filled LuaJIT's ctype table: `table overflow`); any error turns it off for the
  session (logged once).
  `hd2.input.wheel_status()` reports `{hooked, disabled, source, engine}`; the first source that delivers a notch is
  logged (`wheel: first wheel input from ...`), so a live test tells which one works.

Tests: `tests/test_editor_services.py` (`WheelTests`).
